package com.brainmentors.game;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class Board extends JPanel {
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.setColor(Color.RED);
		//g.fillRect(x,y,w,h);
		g.fillRect(40, 40, 400, 40);
		g.setColor(Color.BLUE);
		//g.drawOval(100, 100, 100, 100);
		g.fillOval(100, 100, 100, 100);
	}
}
