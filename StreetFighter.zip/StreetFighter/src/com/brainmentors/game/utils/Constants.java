package com.brainmentors.game.utils;

public interface Constants {
	int SCREENHEIGHT = 900;
	int SCREENWIDTH = 1700;
	String TITLE = "Street Fighter By Brain Mentors";
}
