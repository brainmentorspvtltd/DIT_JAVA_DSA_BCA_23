package com.brainmentors.game.utils;

public interface Constants {
	int SCREENHEIGHT = 700;
	int SCREENWIDTH = 1300;
	String TITLE = "Street Fighter By Brain Mentors";
}
