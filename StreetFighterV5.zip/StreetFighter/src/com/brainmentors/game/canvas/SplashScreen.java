package com.brainmentors.game.canvas;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import com.brainmentors.game.utils.Constants;

public class SplashScreen extends JFrame implements Constants {
	
	private JLabel label = new JLabel();
	
	public SplashScreen() {
		
		setTitle(TITLE);
		setSize(SCREENWIDTH, SCREENHEIGHT);
		setLocationRelativeTo(null);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		Icon icon = new ImageIcon(SplashScreen.class.getResource(SPLASH_BG));
		label.setIcon(icon);
		this.add(label);
		
		setVisible(true);
		
//		try {
//			GameFrame obj = new GameFrame();
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}

	public static void main(String[] args) {
		SplashScreen screen = new SplashScreen();
	}

}
