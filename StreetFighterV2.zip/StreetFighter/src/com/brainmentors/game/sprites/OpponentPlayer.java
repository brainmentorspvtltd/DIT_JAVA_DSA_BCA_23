package com.brainmentors.game.sprites;

import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import com.brainmentors.game.utils.Constants;

public class OpponentPlayer extends CommonPlayer implements Constants {
	
	private BufferedImage idleImages[] = new BufferedImage[5];
	
	public OpponentPlayer() throws Exception {
		x = SCREENWIDTH - 500;
		h = 200;
		w = 150;
		y = FLOOR - h;
		speed = -10;
		playerImg = ImageIO.read(Player.class.getResource("ryu_.png"));
		//playerImg = ImageIO.read(Player.class.getResource("thor.png"));
		loadIdleImages();
	}
	
	private void loadIdleImages() {
		idleImages[0] = playerImg.getSubimage(2961, 40, 106, 228);
		idleImages[1] = playerImg.getSubimage(2748, 40, 107, 228);
		idleImages[2] = playerImg.getSubimage(2555, 33, 108, 235);
		idleImages[3] = playerImg.getSubimage(2359, 38, 104, 230);
		idleImages[4] = playerImg.getSubimage(2174, 47, 91, 217);
	}
	
//	@Override
//	public BufferedImage idle() {
//		//X = 2749 Y = 35 Width = 101 Height = 232
//		return playerImg.getSubimage(2749, 35, 101, 232);
//		//return playerImg.getSubimage(698, 20, 201, 234);
//	}
	
	@Override
	public BufferedImage defaultImage() {
		if(imageIndex > 3) {
			imageIndex = 0;
		}
		//X = 47 Y = 245 Width = 109 Height = 243
		//return playerImg.getSubimage(45, 245, 109, 243);
		//return playerImg.getSubimage(698, 20, 201, 234);
		BufferedImage img = idleImages[imageIndex];
		imageIndex++;
		return img;
	}
}
